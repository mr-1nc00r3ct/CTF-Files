from flask import Flask, request, jsonify
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import os

app = Flask(__name__)

@app.route('/encrypt', methods=['POST'])
def encrypt_string():
    key = b'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
    flag = 'ACVCTF{XXXXXXXXXXXXXXXXXXXXXXXXXXXX}' # This is only a placeholder
    input_string = request.json['input_string']
    block_size = 16
    input_string_flag = pad(input_string.encode() + flag.encode(), block_size)
    cipher = AES.new(key, AES.MODE_ECB)
    ciphertext = cipher.encrypt(input_string_flag)
    num_blocks = (len(ciphertext) + block_size - 1) // block_size
    encrypted_blocks = [ciphertext[i*block_size:(i+1)*block_size].hex() for i in range(num_blocks)]
    return jsonify({'ciphertext': encrypted_blocks})

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5000)