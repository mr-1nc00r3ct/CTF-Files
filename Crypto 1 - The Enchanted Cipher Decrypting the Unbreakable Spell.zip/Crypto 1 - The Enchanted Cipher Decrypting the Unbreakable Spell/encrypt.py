import requests

def encrypt(input_string):
    url = 'http://localhost/encrypt' # Change "localhost" to actual challenge IP
    data = {'input_string': input_string}
    response = requests.post(url, json=data)
    encrypted_blocks = response.json()['ciphertext']
    return encrypted_blocks